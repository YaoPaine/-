package com.yao.chapter1.sign;

public class Salt {

	String a() {
		return "231 204 159";
	}

	String b() {
		return "249 216 195 135 150 159 162";
	}

	String c() {
		return "255 252 210 135 168";
	}

	String d() {
		return "291 336 336 252 315 327 303 345 348 291 327 336";
	}

	String e() {
		return "291 336 336 225 303 363";
	}

	String f() {
		return "345 315 309 330";
	}

	String g() {
		return "291 330 300 342 333 315 300 285 324 321 171 168 306 168 153";
	}

	String h() {
		return "306 324 354 318 321 153 156 150 159 168 171 306 300 309 318 324 153 156 327 171 345 300 351 306 309 150 153 156 333 315 363";
	}

}
